import BarraTopo from '../components/BarraTopo'
import { modelosImpressao } from '../data/mockData'

export default function TelaModelos({ onVoltar }) {
  return (
    <>
      <BarraTopo
        titulo="Imprimir modelos"
        subtitulo="Abrir ou imprimir os documentos-base sem navegar por pastas e sem risco de se perder no Explorer."
        voltar
        onVoltar={onVoltar}
      />

      <div className="grid gap-5 md:grid-cols-2">
        {modelosImpressao.map((item) => (
          <div key={item} className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <h3 className="text-2xl font-bold text-slate-900">{item}</h3>
            <div className="mt-5 flex flex-col gap-3 md:flex-row">
              <button className="rounded-2xl bg-slate-900 px-5 py-4 text-lg font-semibold text-white">
                Abrir
              </button>
              <button className="rounded-2xl bg-white px-5 py-4 text-lg font-semibold text-slate-700 ring-1 ring-slate-200">
                Imprimir
              </button>
            </div>
          </div>
        ))}
      </div>
    </>
  )
}
