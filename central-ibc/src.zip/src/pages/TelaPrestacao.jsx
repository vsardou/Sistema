import BarraTopo from '../components/BarraTopo'

export default function TelaPrestacao({ onVoltar }) {
  return (
    <>
      <BarraTopo
        titulo="Prestacao de contas"
        subtitulo="Fluxo guiado com possibilidade de descricao livre e geracao de Word a partir do modelo que ele ja conhece."
        voltar
        onVoltar={onVoltar}
      />

      <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200 md:p-8">
        <div className="grid gap-4 md:grid-cols-2">
          <input
            className="rounded-2xl border border-slate-200 px-4 py-4 text-lg"
            placeholder="Nome do aluno"
          />
          <input
            className="rounded-2xl border border-slate-200 px-4 py-4 text-lg"
            placeholder="Periodo"
          />
          <input
            className="rounded-2xl border border-slate-200 px-4 py-4 text-lg"
            placeholder="Hospedagem"
          />
          <input
            className="rounded-2xl border border-slate-200 px-4 py-4 text-lg"
            placeholder="Aluguel de aparelho"
          />
          <textarea
            className="min-h-[140px] rounded-2xl border border-slate-200 px-4 py-4 text-lg md:col-span-2"
            placeholder="Treinou de 13 a 18/04, com hospedagem na semana toda. Treinou tambem 25 e 26/04."
          />
        </div>
        <div className="mt-6 flex flex-col gap-3 md:flex-row">
          <button className="rounded-2xl bg-slate-900 px-5 py-4 text-lg font-semibold text-white">
            Interpretar com IA
          </button>
          <button className="rounded-2xl bg-white px-5 py-4 text-lg font-semibold text-slate-700 ring-1 ring-slate-200">
            Gerar Word
          </button>
        </div>
      </div>
    </>
  )
}
