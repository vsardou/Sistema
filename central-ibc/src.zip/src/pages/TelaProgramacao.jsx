import { useMemo, useState } from 'react'
import BarraTopo from '../components/BarraTopo'
import { programacaoMensalInicial } from '../data/mockData'

const nomesMeses = [
  'janeiro',
  'fevereiro',
  'marco',
  'abril',
  'maio',
  'junho',
  'julho',
  'agosto',
  'setembro',
  'outubro',
  'novembro',
  'dezembro',
]

const diasSemana = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab', 'Dom']

const opcoesCor = [
  {
    value: 'emerald',
    dotClass: 'bg-emerald-500',
    chipClass: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
  },
  {
    value: 'sky',
    dotClass: 'bg-sky-500',
    chipClass: 'bg-sky-50 text-sky-700 ring-sky-200',
  },
  {
    value: 'amber',
    dotClass: 'bg-amber-500',
    chipClass: 'bg-amber-50 text-amber-700 ring-amber-200',
  },
  {
    value: 'rose',
    dotClass: 'bg-rose-500',
    chipClass: 'bg-rose-50 text-rose-700 ring-rose-200',
  },
  {
    value: 'violet',
    dotClass: 'bg-violet-500',
    chipClass: 'bg-violet-50 text-violet-700 ring-violet-200',
  },
  {
    value: 'orange',
    dotClass: 'bg-orange-500',
    chipClass: 'bg-orange-50 text-orange-700 ring-orange-200',
  },
  {
    value: 'cyan',
    dotClass: 'bg-cyan-500',
    chipClass: 'bg-cyan-50 text-cyan-700 ring-cyan-200',
  },
  {
    value: 'lime',
    dotClass: 'bg-lime-500',
    chipClass: 'bg-lime-50 text-lime-700 ring-lime-200',
  },
  {
    value: 'pink',
    dotClass: 'bg-pink-500',
    chipClass: 'bg-pink-50 text-pink-700 ring-pink-200',
  },
]

const coresPorValor = Object.fromEntries(opcoesCor.map((opcao) => [opcao.value, opcao]))
const coresAutomaticas = opcoesCor.map((opcao) => opcao.value)

const estiloCancelado = {
  dotClass: 'bg-slate-400',
  chipClass: 'bg-slate-100 text-slate-500 ring-slate-200',
}

const estilosStatus = {
  confirmado: 'bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200',
  'em andamento': 'bg-amber-50 text-amber-700 ring-1 ring-amber-200',
  planejado: 'bg-sky-50 text-sky-700 ring-1 ring-sky-200',
  concluido: 'bg-slate-100 text-slate-700 ring-1 ring-slate-200',
  cancelado: 'bg-slate-100 text-slate-500 ring-1 ring-slate-200',
}

const cartaoPrincipalClass = 'rounded-3xl border border-slate-300 bg-white p-6 shadow-sm md:p-8'
const cartaoSecundarioClass = 'rounded-2xl bg-slate-50 p-4 ring-1 ring-slate-200'
const botaoPrimarioClass =
  'rounded-2xl bg-[#C40010] px-5 py-4 text-base font-semibold text-white transition hover:bg-[#A3000D]'
const botaoSecundarioClass =
  'rounded-2xl bg-white px-5 py-4 text-base font-semibold text-slate-700 ring-1 ring-slate-300 transition hover:bg-slate-50'
const botaoSecundarioCompactoClass =
  'rounded-2xl bg-white px-4 py-3 text-sm font-semibold text-slate-700 ring-1 ring-slate-300 transition hover:bg-slate-50'

function criarChaveData(ano, mes, dia) {
  return `${ano}-${String(mes).padStart(2, '0')}-${String(dia).padStart(2, '0')}`
}

function criarDataLocal(chaveData) {
  const [ano, mes, dia] = chaveData.split('-').map(Number)
  return new Date(ano, mes - 1, dia, 12)
}

function formatarMesAno(mes, ano) {
  return `${nomesMeses[mes - 1]} de ${ano}`
}

function formatarDataExtensa(data) {
  const [ano, mes, dia] = data.split('-').map(Number)
  return `${dia} de ${nomesMeses[mes - 1]} de ${ano}`
}

function formatarDataCurta(data) {
  if (!data) return 'Sem prova definida'

  const [ano, mes, dia] = data.split('-')
  return `${dia}/${mes}/${ano}`
}

function getInfoMes(ano, mes) {
  const primeiroDia = new Date(ano, mes - 1, 1)
  const totalDias = new Date(ano, mes, 0).getDate()
  const deslocamentoInicial = (primeiroDia.getDay() + 6) % 7

  return { totalDias, deslocamentoInicial }
}

function getMesInicial() {
  const hoje = new Date()
  const mesAtual = hoje.getMonth() + 1
  const anoAtual = hoje.getFullYear()
  const mesExiste = programacaoMensalInicial.some(
    (item) => item.mes === mesAtual && item.ano === anoAtual,
  )

  if (mesExiste) {
    return { mes: mesAtual, ano: anoAtual }
  }

  return {
    mes: programacaoMensalInicial[0]?.mes ?? mesAtual,
    ano: programacaoMensalInicial[0]?.ano ?? anoAtual,
  }
}

function getProgramacoesDoDia(programacoes, data) {
  return programacoes.filter((item) => item.dias.includes(data))
}

function getContagemPrincipal(programacoes) {
  return programacoes.filter((item) => item.status !== 'cancelado').length
}

function ehFimDeSemana(data) {
  const diaSemana = criarDataLocal(data).getDay()
  return diaSemana === 0 || diaSemana === 6
}

function ordenarDatas(datas) {
  return [...new Set(datas)].sort()
}

function getCorAutomatica(chave) {
  const base = (chave || 'treinamento').trim().toLowerCase()
  let hash = 0

  for (let indice = 0; indice < base.length; indice += 1) {
    hash = (hash + base.charCodeAt(indice) * (indice + 1)) % coresAutomaticas.length
  }

  return coresAutomaticas[hash]
}

function agruparProgramacoesPorGrupo(agendaMensal) {
  const mapa = new Map()
  const agendaOrdenada = [...agendaMensal].sort((a, b) => a.ano - b.ano || a.mes - b.mes)

  agendaOrdenada.forEach((mesItem) => {
    mesItem.programacoes.forEach((programacao) => {
      const existente = mapa.get(programacao.grupoId)

      if (existente) {
        existente.dias.push(...programacao.dias)
        existente.segmentos.push(programacao)
        return
      }

      mapa.set(programacao.grupoId, {
        ...programacao,
        dias: [...programacao.dias],
        segmentos: [programacao],
      })
    })
  })

  return [...mapa.values()].map((item) => {
    const dias = ordenarDatas(item.dias)

    return {
      ...item,
      dias,
      dataInicial: dias[0] ?? item.dataInicial,
      dataFinal: dias.at(-1) ?? item.dataFinal,
    }
  })
}

function removerProgramacaoGrupo(agendaMensal, grupoId) {
  return agendaMensal.map((mesItem) => ({
    ...mesItem,
    programacoes: mesItem.programacoes.filter((programacao) => programacao.grupoId !== grupoId),
  }))
}

function atualizarStatusGrupo(agendaMensal, grupoId, novoStatus) {
  return agendaMensal.map((mesItem) => ({
    ...mesItem,
    programacoes: mesItem.programacoes.map((programacao) =>
      programacao.grupoId === grupoId ? { ...programacao, status: novoStatus } : programacao,
    ),
  }))
}

function salvarProgramacaoAgrupada(agendaMensal, programacaoBase) {
  const dias = ordenarDatas(programacaoBase.dias)

  if (dias.length === 0) {
    return agendaMensal
  }

  const agendaSemGrupo = removerProgramacaoGrupo(agendaMensal, programacaoBase.grupoId)
  const agendaAtualizada = agendaSemGrupo.map((item) => ({
    ...item,
    programacoes: [...item.programacoes],
  }))

  const diasPorMes = dias.reduce((acumulado, data) => {
    const [ano, mes] = data.split('-')
    const chave = `${ano}-${mes}`

    if (!acumulado.has(chave)) {
      acumulado.set(chave, [])
    }

    acumulado.get(chave).push(data)
    return acumulado
  }, new Map())

  diasPorMes.forEach((diasDoMes, chave) => {
    const [anoTexto, mesTexto] = chave.split('-')
    const ano = Number(anoTexto)
    const mes = Number(mesTexto)
    const indiceMes = agendaAtualizada.findIndex((item) => item.mes === mes && item.ano === ano)
    const segmento = {
      ...programacaoBase,
      id: `${programacaoBase.grupoId}-${ano}-${mes}`,
      dias: diasDoMes,
    }

    if (indiceMes >= 0) {
      agendaAtualizada[indiceMes] = {
        ...agendaAtualizada[indiceMes],
        programacoes: [segmento, ...agendaAtualizada[indiceMes].programacoes],
      }
      return
    }

    agendaAtualizada.push({
      mes,
      ano,
      programacoes: [segmento],
    })
  })

  return agendaAtualizada.sort((a, b) => a.ano - b.ano || a.mes - b.mes)
}

function formatarQuantidadeAlunos(total) {
  if (total === 1) return '1 aluno'
  return `${total} alunos`
}

function criarFormularioInicial(dataBase = '') {
  return {
    nomeAluno: '',
    tipoTreinamento: '',
    dataProva: dataBase,
    observacoes: '',
    diasSelecionados: dataBase ? [dataBase] : [],
    pularFimDeSemana: true,
  }
}

function criarFormularioEdicao(programacao) {
  return {
    nomeAluno: programacao.aluno,
    tipoTreinamento: programacao.tipoTreinamento,
    dataProva: programacao.dataProva,
    observacoes: programacao.observacoes,
    diasSelecionados: [...programacao.dias],
    pularFimDeSemana: programacao.pularFimDeSemana,
  }
}

export default function TelaProgramacao({ onVoltar }) {
  const mesInicial = getMesInicial()
  const [agendaMensal, setAgendaMensal] = useState(programacaoMensalInicial)
  const [mesAtual, setMesAtual] = useState(mesInicial.mes)
  const [anoAtual, setAnoAtual] = useState(mesInicial.ano)
  const [dataSelecionada, setDataSelecionada] = useState(null)
  const [programacaoSelecionadaId, setProgramacaoSelecionadaId] = useState(null)
  const [modalAberto, setModalAberto] = useState(false)
  const [modoModal, setModoModal] = useState('adicionar')
  const [grupoEmEdicao, setGrupoEmEdicao] = useState(null)
  const [mesSelecao, setMesSelecao] = useState(mesInicial.mes)
  const [anoSelecao, setAnoSelecao] = useState(mesInicial.ano)
  const [formulario, setFormulario] = useState(criarFormularioInicial())

  const agendaDoMes = useMemo(
    () =>
      agendaMensal.find((item) => item.mes === mesAtual && item.ano === anoAtual) ?? {
        mes: mesAtual,
        ano: anoAtual,
        programacoes: [],
      },
    [agendaMensal, anoAtual, mesAtual],
  )

  const programacoesAgrupadas = useMemo(
    () => agruparProgramacoesPorGrupo(agendaMensal),
    [agendaMensal],
  )

  const programacoesPorGrupo = useMemo(
    () => new Map(programacoesAgrupadas.map((programacao) => [programacao.grupoId, programacao])),
    [programacoesAgrupadas],
  )

  const programacaoSelecionada = programacoesPorGrupo.get(programacaoSelecionadaId) ?? null

  const diasDoCalendario = useMemo(() => {
    const { totalDias, deslocamentoInicial } = getInfoMes(anoAtual, mesAtual)
    const dias = []

    for (let indice = 0; indice < deslocamentoInicial; indice += 1) {
      dias.push({
        key: `vazio-inicio-${indice}`,
        vazio: true,
      })
    }

    for (let dia = 1; dia <= totalDias; dia += 1) {
      const data = criarChaveData(anoAtual, mesAtual, dia)
      const programacoes = getProgramacoesDoDia(agendaDoMes.programacoes, data)

      dias.push({
        key: data,
        vazio: false,
        data,
        dia,
        programacoes,
        contagemPrincipal: getContagemPrincipal(programacoes),
        contagemCancelados: programacoes.filter((item) => item.status === 'cancelado').length,
      })
    }

    const espacosFinais = (7 - (dias.length % 7)) % 7

    for (let indice = 0; indice < espacosFinais; indice += 1) {
      dias.push({
        key: `vazio-fim-${indice}`,
        vazio: true,
      })
    }

    return dias
  }, [agendaDoMes.programacoes, anoAtual, mesAtual])

  const diasDoCalendarioSelecao = useMemo(() => {
    const { totalDias, deslocamentoInicial } = getInfoMes(anoSelecao, mesSelecao)
    const dias = []

    for (let indice = 0; indice < deslocamentoInicial; indice += 1) {
      dias.push({
        key: `modal-vazio-inicio-${indice}`,
        vazio: true,
      })
    }

    for (let dia = 1; dia <= totalDias; dia += 1) {
      const data = criarChaveData(anoSelecao, mesSelecao, dia)
      const desabilitado = formulario.pularFimDeSemana && ehFimDeSemana(data)

      dias.push({
        key: data,
        vazio: false,
        data,
        dia,
        selecionado: formulario.diasSelecionados.includes(data),
        desabilitado,
      })
    }

    const espacosFinais = (7 - (dias.length % 7)) % 7

    for (let indice = 0; indice < espacosFinais; indice += 1) {
      dias.push({
        key: `modal-vazio-fim-${indice}`,
        vazio: true,
      })
    }

    return dias
  }, [anoSelecao, formulario.diasSelecionados, formulario.pularFimDeSemana, mesSelecao])

  const resumoDoMes = useMemo(() => {
    const programacoesAtivas = agendaDoMes.programacoes.filter((item) => item.status !== 'cancelado')
    const programacoesCanceladas = agendaDoMes.programacoes.filter(
      (item) => item.status === 'cancelado',
    )
    const diasOcupados = diasDoCalendario.filter(
      (item) => !item.vazio && item.contagemPrincipal > 0,
    ).length

    return {
      diasOcupados,
      totalAtivos: programacoesAtivas.length,
      totalCancelados: programacoesCanceladas.length,
    }
  }, [agendaDoMes.programacoes, diasDoCalendario])

  const programacoesDaDataSelecionada = useMemo(() => {
    if (!dataSelecionada) return []
    return getProgramacoesDoDia(agendaDoMes.programacoes, dataSelecionada)
  }, [agendaDoMes.programacoes, dataSelecionada])

  const diasSelecionadosOrdenados = useMemo(
    () => ordenarDatas(formulario.diasSelecionados),
    [formulario.diasSelecionados],
  )

  const corPreview = useMemo(() => {
    if (modoModal === 'editar' && programacaoSelecionada) {
      return programacaoSelecionada.cor
    }

    return getCorAutomatica(formulario.nomeAluno || `treinamento-${programacoesAgrupadas.length}`)
  }, [formulario.nomeAluno, modoModal, programacaoSelecionada, programacoesAgrupadas.length])

  function handleTrocarMes(direcao) {
    const proximaData = new Date(anoAtual, mesAtual - 1 + direcao, 1)
    setMesAtual(proximaData.getMonth() + 1)
    setAnoAtual(proximaData.getFullYear())
    setDataSelecionada(null)
    setProgramacaoSelecionadaId(null)
  }

  function handleTrocarMesSelecao(direcao) {
    const proximaData = new Date(anoSelecao, mesSelecao - 1 + direcao, 1)
    setMesSelecao(proximaData.getMonth() + 1)
    setAnoSelecao(proximaData.getFullYear())
  }

  function handleSelecionarDia(data) {
    setDataSelecionada(data)
    setProgramacaoSelecionadaId(null)
  }

  function handleAbrirProgramacao(programacao, data) {
    setDataSelecionada(data)
    setProgramacaoSelecionadaId(programacao.grupoId)
  }

  function handleAbrirAdicionarTreinamento() {
    const dataBase = dataSelecionada ?? ''

    setModoModal('adicionar')
    setGrupoEmEdicao(null)
    setFormulario(criarFormularioInicial(dataBase))

    if (dataBase) {
      const [ano, mes] = dataBase.split('-').map(Number)
      setAnoSelecao(ano)
      setMesSelecao(mes)
    } else {
      setAnoSelecao(anoAtual)
      setMesSelecao(mesAtual)
    }

    setModalAberto(true)
  }

  function handleAbrirEdicao() {
    if (!programacaoSelecionada) {
      return
    }

    setModoModal('editar')
    setGrupoEmEdicao(programacaoSelecionada.grupoId)
    setFormulario(criarFormularioEdicao(programacaoSelecionada))

    const [ano, mes] = programacaoSelecionada.dataInicial.split('-').map(Number)
    setAnoSelecao(ano)
    setMesSelecao(mes)
    setModalAberto(true)
  }

  function handleFecharModal() {
    setModalAberto(false)
    setGrupoEmEdicao(null)
  }

  function handleAtualizarFormulario(campo, valor) {
    setFormulario((atual) => ({
      ...atual,
      [campo]: valor,
    }))
  }

  function handleAlternarFimDeSemana(checked) {
    setFormulario((atual) => ({
      ...atual,
      pularFimDeSemana: checked,
      diasSelecionados: checked
        ? atual.diasSelecionados.filter((data) => !ehFimDeSemana(data))
        : atual.diasSelecionados,
    }))
  }

  function handleAlternarDiaSelecao(data) {
    if (formulario.pularFimDeSemana && ehFimDeSemana(data)) {
      return
    }

    setFormulario((atual) => {
      const existe = atual.diasSelecionados.includes(data)
      const diasSelecionados = existe
        ? atual.diasSelecionados.filter((item) => item !== data)
        : ordenarDatas([...atual.diasSelecionados, data])

      return {
        ...atual,
        diasSelecionados,
      }
    })
  }

  function handleLimparSelecao() {
    setFormulario((atual) => ({
      ...atual,
      diasSelecionados: [],
    }))
  }

  function handleSalvarProgramacao(event) {
    event.preventDefault()

    const nomeAluno = formulario.nomeAluno.trim()
    const dias = ordenarDatas(formulario.diasSelecionados)

    if (!nomeAluno || dias.length === 0) {
      return
    }

    const grupoId = grupoEmEdicao ?? `grupo-${Date.now()}`
    const cor = programacaoSelecionada?.cor ?? getCorAutomatica(nomeAluno)
    const tipoTreinamento = formulario.tipoTreinamento.trim() || 'Treinamento mensal'
    const observacoes =
      formulario.observacoes.trim() || 'Programacao criada diretamente no calendario mensal.'

    const novaProgramacao = {
      id: grupoId,
      grupoId,
      aluno: nomeAluno,
      cor,
      tipoTreinamento,
      dataProva: formulario.dataProva || dias.at(-1),
      observacoes,
      dataInicial: dias[0],
      dataFinal: dias.at(-1),
      pularFimDeSemana: formulario.pularFimDeSemana,
      dias,
      status: programacaoSelecionada?.status ?? 'planejado',
    }

    const agendaAtualizada = salvarProgramacaoAgrupada(agendaMensal, novaProgramacao)
    const primeiraData = dias[0]
    const [ano, mes] = primeiraData.split('-').map(Number)

    setAgendaMensal(agendaAtualizada)
    setAnoAtual(ano)
    setMesAtual(mes)
    setDataSelecionada(primeiraData)
    setProgramacaoSelecionadaId(grupoId)
    setModalAberto(false)
    setGrupoEmEdicao(null)
    setFormulario(criarFormularioInicial())
  }

  function handleRemoverProgramacao() {
    if (!programacaoSelecionada) {
      return
    }

    const confirmou = window.confirm(
      `Remover o treinamento de ${programacaoSelecionada.aluno} do calendario?`,
    )

    if (!confirmou) {
      return
    }

    setAgendaMensal((atual) =>
      removerProgramacaoGrupo(atual, programacaoSelecionada.grupoId),
    )
    setProgramacaoSelecionadaId(null)
  }

  function handleCancelarProgramacao() {
    if (!programacaoSelecionada || programacaoSelecionada.status === 'cancelado') {
      return
    }

    const confirmou = window.confirm(
      `Cancelar o treinamento de ${programacaoSelecionada.aluno} e manter visivel em cinza?`,
    )

    if (!confirmou) {
      return
    }

    setAgendaMensal((atual) =>
      atualizarStatusGrupo(atual, programacaoSelecionada.grupoId, 'cancelado'),
    )
  }

  return (
    <>
      <BarraTopo
        titulo="Programacao mensal"
        subtitulo="Calendario operacional para enxergar o mes, localizar alunos rapido e lancar treinamentos sem depender de Word."
        voltar
        onVoltar={onVoltar}
      />

      <section className={cartaoPrincipalClass}>
        <div className="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[#C40010]">
              Agenda operacional
            </p>
            <h3 className="mt-2 text-3xl font-bold text-slate-900 md:text-4xl">
              {formatarMesAno(mesAtual, anoAtual)}
            </h3>
            <p className="mt-3 max-w-3xl text-base text-slate-600">
              O calendario e a visao principal. Cada dia mostra ocupacao, nomes visiveis e
              acesso rapido ao detalhe do treinamento.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <button
              type="button"
              onClick={() => handleTrocarMes(-1)}
              className={botaoSecundarioClass}
            >
              Mes anterior
            </button>
            <button
              type="button"
              onClick={() => handleTrocarMes(1)}
              className={botaoSecundarioClass}
            >
              Proximo mes
            </button>
            <button
              type="button"
              onClick={handleAbrirAdicionarTreinamento}
              className={botaoPrimarioClass}
            >
              Adicionar treinamento
            </button>
          </div>
        </div>

        <div className="mt-6 grid gap-3 md:grid-cols-3">
          <div className={cartaoSecundarioClass}>
            <span className="text-sm font-semibold text-slate-500">Dias ocupados</span>
            <p className="mt-2 text-3xl font-bold text-slate-900">{resumoDoMes.diasOcupados}</p>
          </div>
          <div className={cartaoSecundarioClass}>
            <span className="text-sm font-semibold text-slate-500">Treinamentos ativos</span>
            <p className="mt-2 text-3xl font-bold text-slate-900">{resumoDoMes.totalAtivos}</p>
          </div>
          <div className={cartaoSecundarioClass}>
            <span className="text-sm font-semibold text-slate-500">Cancelados visiveis</span>
            <p className="mt-2 text-3xl font-bold text-slate-900">
              {resumoDoMes.totalCancelados}
            </p>
          </div>
        </div>

        <div className="mt-8 overflow-x-auto pb-2">
          <div className="grid min-w-[860px] grid-cols-7 gap-3">
            {diasSemana.map((diaSemana) => (
              <div
                key={diaSemana}
                className="rounded-2xl bg-slate-900 px-3 py-3 text-center text-sm font-semibold uppercase tracking-[0.16em] text-slate-100"
              >
                {diaSemana}
              </div>
            ))}

            {diasDoCalendario.map((item) => {
              if (item.vazio) {
                return (
                  <div
                    key={item.key}
                    className="min-h-[176px] rounded-3xl border border-dashed border-slate-200 bg-slate-50/60"
                  />
                )
              }

              const programacoesVisiveis = item.programacoes.slice(0, 3)
              const programacoesOcultas = item.programacoes.length - programacoesVisiveis.length
              const estaSelecionado = dataSelecionada === item.data

              return (
                <div
                  key={item.key}
                  className={[
                    'min-h-[176px] rounded-3xl border p-4 transition',
                    item.programacoes.length > 0
                      ? 'border-slate-200 bg-white shadow-sm'
                      : 'border-dashed border-slate-200 bg-slate-50/70',
                    estaSelecionado ? 'border-[#C40010] ring-2 ring-[#C40010]/15' : '',
                  ].join(' ')}
                >
                  <button
                    type="button"
                    onClick={() => handleSelecionarDia(item.data)}
                    className="w-full text-left"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <span className="text-2xl font-bold text-slate-900">{item.dia}</span>
                      <div className="text-right">
                      <span className="block rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold uppercase tracking-[0.16em] text-slate-700">
                        {formatarQuantidadeAlunos(item.contagemPrincipal)}
                      </span>
                        {item.contagemCancelados > 0 ? (
                          <span className="mt-2 block text-xs font-semibold text-slate-400">
                            {item.contagemCancelados} cancelado(s)
                          </span>
                        ) : null}
                      </div>
                    </div>
                  </button>

                  <div className="mt-4 space-y-2">
                    {item.programacoes.length === 0 ? (
                      <div className="rounded-2xl border border-dashed border-slate-200 bg-white/80 px-3 py-4 text-sm font-medium text-slate-400">
                        Livre
                      </div>
                    ) : (
                      programacoesVisiveis.map((programacao) => {
                        const corAtual =
                          programacao.status === 'cancelado'
                            ? estiloCancelado
                            : (coresPorValor[programacao.cor] ?? coresPorValor.emerald)
                        const estaAtiva = programacaoSelecionadaId === programacao.grupoId

                        return (
                          <button
                            key={programacao.id}
                            type="button"
                            onClick={() => handleAbrirProgramacao(programacao, item.data)}
                            className={`flex w-full items-center gap-2 rounded-2xl px-3 py-2 text-left text-sm font-medium ring-1 transition hover:-translate-y-0.5 ${corAtual.chipClass} ${estaAtiva ? 'ring-2 ring-slate-900/10' : ''}`}
                          >
                            <span
                              className={`h-3 w-3 rounded-full ${corAtual.dotClass}`}
                              aria-hidden="true"
                            />
                            <span className="truncate">{programacao.aluno}</span>
                          </button>
                        )
                      })
                    )}

                    {programacoesOcultas > 0 ? (
                      <button
                        type="button"
                        onClick={() => handleSelecionarDia(item.data)}
                        className="w-full rounded-2xl bg-slate-100 px-3 py-2 text-left text-sm font-semibold text-slate-700 transition hover:bg-slate-200"
                      >
                        +{programacoesOcultas}
                      </button>
                    ) : null}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      <div className="mt-6 grid gap-6 xl:grid-cols-[0.95fr_1.05fr]">
        <section className={cartaoPrincipalClass}>
          <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
            <div>
              <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[#C40010]">
                Detalhe do dia
              </p>
              <h3 className="mt-2 text-2xl font-bold text-slate-900 md:text-3xl">
                {dataSelecionada ? formatarDataExtensa(dataSelecionada) : 'Selecione um dia'}
              </h3>
            </div>
            {dataSelecionada ? (
              <div className="rounded-2xl bg-slate-100 px-4 py-3 text-sm font-semibold text-slate-700">
                {formatarQuantidadeAlunos(getContagemPrincipal(programacoesDaDataSelecionada))}
              </div>
            ) : null}
          </div>

          <p className="mt-3 text-base text-slate-600">
            {dataSelecionada
              ? 'Clique em qualquer bloco para abrir o treinamento completo. Os itens seguem a ordem de criacao.'
              : 'Use o calendario acima para abrir um dia e enxergar todos os treinamentos daquela data.'}
          </p>

          <div className="mt-6 space-y-3">
            {dataSelecionada && programacoesDaDataSelecionada.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-slate-200 bg-slate-50 px-4 py-5 text-sm text-slate-500">
                Nenhum treinamento marcado neste dia.
              </div>
            ) : null}

            {programacoesDaDataSelecionada.map((programacao) => {
              const corAtual =
                programacao.status === 'cancelado'
                  ? estiloCancelado
                  : (coresPorValor[programacao.cor] ?? coresPorValor.emerald)
              const statusClass =
                estilosStatus[programacao.status] ?? 'bg-slate-100 text-slate-700 ring-1 ring-slate-200'
              const estaAtiva = programacaoSelecionadaId === programacao.grupoId

              return (
                <button
                  key={programacao.id}
                  type="button"
                  onClick={() => handleAbrirProgramacao(programacao, dataSelecionada)}
                  className={`w-full rounded-3xl bg-slate-50 p-4 text-left ring-1 ring-slate-200 transition hover:-translate-y-0.5 hover:shadow-sm ${estaAtiva ? 'ring-2 ring-[#C40010]/15' : ''}`}
                >
                  <div className="flex flex-col gap-3">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <span
                          className={`h-4 w-4 rounded-full ${corAtual.dotClass}`}
                          aria-hidden="true"
                        />
                        <div>
                          <p className="text-lg font-semibold text-slate-900">{programacao.aluno}</p>
                          <p className="text-sm text-slate-600">
                            {programacao.tipoTreinamento || 'Sem tipo informado'}
                          </p>
                        </div>
                      </div>
                      <span
                        className={`rounded-full px-3 py-1 text-xs font-semibold uppercase tracking-[0.16em] ${statusClass}`}
                      >
                        {programacao.status}
                      </span>
                    </div>

                    <div className="grid gap-3 md:grid-cols-2">
                      <div className="rounded-2xl bg-white px-3 py-3 ring-1 ring-slate-200">
                        <span className="block text-xs font-semibold uppercase tracking-[0.14em] text-slate-400">
                          Intervalo
                        </span>
                        <span className="mt-1 block font-medium text-slate-700">
                          {formatarDataCurta(programacao.dataInicial)} a{' '}
                          {formatarDataCurta(programacao.dataFinal)}
                        </span>
                      </div>
                      <div className="rounded-2xl bg-white px-3 py-3 ring-1 ring-slate-200">
                        <span className="block text-xs font-semibold uppercase tracking-[0.14em] text-slate-400">
                          Prova
                        </span>
                        <span className="mt-1 block font-medium text-slate-700">
                          {formatarDataCurta(programacao.dataProva)}
                        </span>
                      </div>
                    </div>
                  </div>
                </button>
              )
            })}
          </div>
        </section>

        <section className={cartaoPrincipalClass}>
          <div className="flex flex-col gap-2 md:flex-row md:items-start md:justify-between">
            <div>
              <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[#C40010]">
                Treinamento selecionado
              </p>
              <h3 className="mt-2 text-2xl font-bold text-slate-900 md:text-3xl">
                {programacaoSelecionada ? programacaoSelecionada.aluno : 'Nenhum treinamento aberto'}
              </h3>
            </div>
            {programacaoSelecionada ? (
              <span
                className={`rounded-full px-3 py-2 text-xs font-semibold uppercase tracking-[0.16em] ${estilosStatus[programacaoSelecionada.status] ?? 'bg-slate-100 text-slate-700 ring-1 ring-slate-200'}`}
              >
                {programacaoSelecionada.status}
              </span>
            ) : null}
          </div>

          {programacaoSelecionada ? (
            <>
              <p className="mt-3 text-base text-slate-600">
                Esse detalhe representa o treinamento inteiro, mesmo quando ele ocupa mais de um
                mes.
              </p>

              <div className="mt-6 grid gap-3 md:grid-cols-2">
                <div className={cartaoSecundarioClass}>
                  <span className="text-sm font-semibold text-slate-500">Tipo</span>
                  <p className="mt-2 text-lg font-semibold text-slate-900">
                    {programacaoSelecionada.tipoTreinamento || 'Sem tipo informado'}
                  </p>
                </div>
                <div className={cartaoSecundarioClass}>
                  <span className="text-sm font-semibold text-slate-500">Cor automatica</span>
                  <div className="mt-3 flex items-center gap-3">
                    <span
                      className={`h-4 w-4 rounded-full ${(programacaoSelecionada.status === 'cancelado'
                        ? estiloCancelado
                        : (coresPorValor[programacaoSelecionada.cor] ?? coresPorValor.emerald)
                      ).dotClass}`}
                      aria-hidden="true"
                    />
                    <span className="text-base font-semibold text-slate-900">
                      Aplicada automaticamente
                    </span>
                  </div>
                </div>
                <div className={cartaoSecundarioClass}>
                  <span className="text-sm font-semibold text-slate-500">Periodo</span>
                  <p className="mt-2 text-lg font-semibold text-slate-900">
                    {formatarDataCurta(programacaoSelecionada.dataInicial)} a{' '}
                    {formatarDataCurta(programacaoSelecionada.dataFinal)}
                  </p>
                </div>
                <div className={cartaoSecundarioClass}>
                  <span className="text-sm font-semibold text-slate-500">Data da prova</span>
                  <p className="mt-2 text-lg font-semibold text-slate-900">
                    {formatarDataCurta(programacaoSelecionada.dataProva)}
                  </p>
                </div>
              </div>

              <div className={`mt-6 ${cartaoSecundarioClass}`}>
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <span className="text-sm font-semibold uppercase tracking-[0.14em] text-slate-500">
                    Dias selecionados
                  </span>
                  <span className="rounded-full bg-white px-3 py-1 text-xs font-semibold text-slate-600 ring-1 ring-slate-200">
                    {programacaoSelecionada.dias.length} dia(s)
                  </span>
                </div>
                <div className="mt-4 flex flex-wrap gap-2">
                  {programacaoSelecionada.dias.slice(0, 10).map((dia) => (
                    <span
                      key={dia}
                      className="rounded-full bg-white px-3 py-2 text-sm font-medium text-slate-700 ring-1 ring-slate-200"
                    >
                      {formatarDataCurta(dia)}
                    </span>
                  ))}
                  {programacaoSelecionada.dias.length > 10 ? (
                    <span className="rounded-full bg-white px-3 py-2 text-sm font-medium text-slate-500 ring-1 ring-slate-200">
                      +{programacaoSelecionada.dias.length - 10}
                    </span>
                  ) : null}
                </div>
              </div>

              <div className={`mt-6 ${cartaoSecundarioClass}`}>
                <span className="text-sm font-semibold uppercase tracking-[0.14em] text-slate-500">
                  Observacoes
                </span>
                <p className="mt-3 text-base leading-relaxed text-slate-700">
                  {programacaoSelecionada.observacoes}
                </p>
              </div>

              <div className="mt-6 flex flex-col gap-3 md:flex-row">
                <button
                  type="button"
                  onClick={handleAbrirEdicao}
                  className={botaoPrimarioClass}
                >
                  Editar
                </button>
                <button
                  type="button"
                  onClick={handleCancelarProgramacao}
                  disabled={programacaoSelecionada.status === 'cancelado'}
                  className="rounded-2xl bg-white px-5 py-4 text-base font-semibold text-slate-700 ring-1 ring-slate-300 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:text-slate-400"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleRemoverProgramacao}
                  className="rounded-2xl bg-white px-5 py-4 text-base font-semibold text-[#C40010] ring-1 ring-[#C40010]/25 transition hover:bg-red-50"
                >
                  Remover
                </button>
              </div>
            </>
          ) : (
            <div className="mt-6 rounded-2xl border border-dashed border-slate-200 bg-slate-50 px-4 py-5 text-sm text-slate-500">
              Clique em qualquer bloco de aluno no calendario ou no detalhe do dia para abrir o
              treinamento completo.
            </div>
          )}
        </section>
      </div>

      {modalAberto ? (
        <div className="fixed inset-0 z-50 bg-slate-950/55 p-4 md:p-8">
          <div className="mx-auto max-h-full max-w-6xl overflow-y-auto rounded-[32px] border border-slate-300 bg-white p-6 shadow-2xl md:p-8">
            <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
              <div>
                <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[#C40010]">
                  {modoModal === 'editar' ? 'Editar treinamento' : 'Adicionar treinamento'}
                </p>
                <h3 className="mt-2 text-3xl font-bold text-slate-900">
                  {modoModal === 'editar' ? 'Ajustar treinamento' : 'Novo treinamento'}
                </h3>
                <p className="mt-3 max-w-3xl text-base text-slate-600">
                  Selecione os dias diretamente no calendario. Voce pode navegar entre meses,
                  limpar a selecao e refazer quantas vezes precisar antes de salvar.
                </p>
              </div>
              <button
                type="button"
                onClick={handleFecharModal}
                className={botaoSecundarioCompactoClass}
              >
                Fechar
              </button>
            </div>

            <div className="mt-6 grid gap-6 xl:grid-cols-[0.78fr_1.22fr]">
              <form className="grid gap-4" onSubmit={handleSalvarProgramacao}>
                <label className="grid gap-2">
                  <span className="text-sm font-semibold text-slate-600">Nome do aluno</span>
                  <input
                    value={formulario.nomeAluno}
                    onChange={(e) => handleAtualizarFormulario('nomeAluno', e.target.value)}
                    className="rounded-2xl border border-slate-200 px-4 py-4 text-base text-slate-900"
                    placeholder="Ex.: Pablo Almeida"
                  />
                </label>

                <div className={cartaoSecundarioClass}>
                  <span className="text-sm font-semibold text-slate-500">Cor automatica</span>
                  <div className="mt-3 flex items-center gap-3">
                    <span
                      className={`h-4 w-4 rounded-full ${(coresPorValor[corPreview] ?? coresPorValor.emerald).dotClass}`}
                      aria-hidden="true"
                    />
                    <span className="text-base font-semibold text-slate-900">
                      Definida automaticamente
                    </span>
                  </div>
                </div>

                <label className="grid gap-2">
                  <span className="text-sm font-semibold text-slate-600">Tipo de treinamento</span>
                  <input
                    value={formulario.tipoTreinamento}
                    onChange={(e) => handleAtualizarFormulario('tipoTreinamento', e.target.value)}
                    className="rounded-2xl border border-slate-200 px-4 py-4 text-base text-slate-900"
                    placeholder="Treinamento inicial, reciclagem, prova..."
                  />
                </label>

                <label className="grid gap-2">
                  <span className="text-sm font-semibold text-slate-600">Data da prova</span>
                  <input
                    type="date"
                    value={formulario.dataProva}
                    onChange={(e) => handleAtualizarFormulario('dataProva', e.target.value)}
                    className="rounded-2xl border border-slate-200 px-4 py-4 text-base text-slate-900"
                  />
                </label>

                <label className="grid gap-2">
                  <span className="text-sm font-semibold text-slate-600">Observacoes</span>
                  <textarea
                    value={formulario.observacoes}
                    onChange={(e) => handleAtualizarFormulario('observacoes', e.target.value)}
                    className="min-h-[120px] rounded-2xl border border-slate-200 px-4 py-4 text-base text-slate-900"
                    placeholder="Detalhes importantes deste treinamento."
                  />
                </label>

                <label className="flex items-center gap-3 rounded-2xl bg-slate-50 px-4 py-4 ring-1 ring-slate-200">
                  <input
                    type="checkbox"
                    checked={formulario.pularFimDeSemana}
                    onChange={(e) => handleAlternarFimDeSemana(e.target.checked)}
                    className="h-5 w-5 rounded border-slate-300 text-slate-900"
                  />
                  <span className="text-sm font-semibold text-slate-700">Pular sabado e domingo</span>
                </label>

                <div className={cartaoSecundarioClass}>
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <span className="text-sm font-semibold text-slate-500">Dias selecionados</span>
                      <p className="mt-2 text-2xl font-bold text-slate-900">
                        {diasSelecionadosOrdenados.length}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={handleLimparSelecao}
                      className={botaoSecundarioCompactoClass}
                    >
                      Limpar selecao
                    </button>
                  </div>

                  <div className="mt-4 text-sm text-slate-600">
                    {diasSelecionadosOrdenados.length > 0 ? (
                      <>
                        <p>
                          De {formatarDataCurta(diasSelecionadosOrdenados[0])} ate{' '}
                          {formatarDataCurta(diasSelecionadosOrdenados.at(-1))}
                        </p>
                        <p className="mt-2">
                          Use o calendario ao lado para marcar ou desmarcar cada dia.
                        </p>
                      </>
                    ) : (
                      <p>Selecione os dias do treinamento no calendario ao lado.</p>
                    )}
                  </div>
                </div>

                <div className="flex flex-col gap-3 md:flex-row">
                  <button
                    type="button"
                    onClick={handleFecharModal}
                    className={botaoSecundarioClass}
                  >
                    Fechar
                  </button>
                  <button
                    type="submit"
                    className={botaoPrimarioClass}
                  >
                    {modoModal === 'editar' ? 'Salvar alteracoes' : 'Salvar treinamento'}
                  </button>
                </div>
              </form>

              <div className="rounded-3xl border border-slate-200 bg-slate-50 p-4 md:p-6">
                <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
                  <div>
                    <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[#C40010]">
                      Selecao de dias
                    </p>
                    <h4 className="mt-2 text-2xl font-bold text-slate-900">
                      {formatarMesAno(mesSelecao, anoSelecao)}
                    </h4>
                  </div>
                  <div className="flex flex-wrap gap-3">
                    <button
                      type="button"
                      onClick={() => handleTrocarMesSelecao(-1)}
                      className={botaoSecundarioCompactoClass}
                    >
                      Mes anterior
                    </button>
                    <button
                      type="button"
                      onClick={() => handleTrocarMesSelecao(1)}
                      className={botaoSecundarioCompactoClass}
                    >
                      Proximo mes
                    </button>
                  </div>
                </div>

                <div className="mt-6 grid grid-cols-7 gap-2 md:gap-3">
                  {diasSemana.map((diaSemana) => (
                    <div
                      key={diaSemana}
                      className="rounded-2xl bg-slate-900 px-2 py-3 text-center text-xs font-semibold uppercase tracking-[0.16em] text-slate-100 md:text-sm"
                    >
                      {diaSemana}
                    </div>
                  ))}

                  {diasDoCalendarioSelecao.map((item) => {
                    if (item.vazio) {
                      return (
                        <div
                          key={item.key}
                          className="min-h-[72px] rounded-2xl border border-dashed border-slate-200 bg-white/60"
                        />
                      )
                    }

                    return (
                      <button
                        key={item.key}
                        type="button"
                        onClick={() => handleAlternarDiaSelecao(item.data)}
                        disabled={item.desabilitado}
                        className={[
                          'min-h-[72px] rounded-2xl border px-2 py-3 text-center text-sm font-semibold transition md:min-h-[88px] md:text-base',
                          item.selecionado
                            ? 'border-[#C40010] bg-[#C40010] text-white shadow-sm'
                            : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50',
                          item.desabilitado
                            ? 'cursor-not-allowed border-dashed text-slate-300 hover:bg-white'
                            : '',
                        ].join(' ')}
                      >
                        {item.dia}
                      </button>
                    )
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </>
  )
}
