import { useMemo, useState } from 'react'
import BarraTopo from '../components/BarraTopo'
import { itensBusca } from '../data/mockData'

export default function TelaBusca({ onVoltar, titulo = 'Buscar documento', subtitulo }) {
  const [termo, setTermo] = useState('')

  const resultados = useMemo(() => {
    const valor = termo.toLowerCase().trim()
    if (!valor) return itensBusca
    return itensBusca.filter((item) => item.toLowerCase().includes(valor))
  }, [termo])

  return (
    <>
      <BarraTopo
        titulo={titulo}
        subtitulo={
          subtitulo || 'Busca simples por nome do aluno, mes, tipo de documento ou palavra-chave.'
        }
        voltar
        onVoltar={onVoltar}
      />

      <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200 md:p-8">
        <input
          value={termo}
          onChange={(e) => setTermo(e.target.value)}
          className="w-full rounded-2xl border border-slate-200 px-4 py-4 text-xl"
          placeholder="Ex.: declaracao eneias, programacao abril, prestacao pablo"
        />
        <div className="mt-6 space-y-3">
          {resultados.map((item) => (
            <button
              key={item}
              className="flex w-full items-center justify-between rounded-2xl bg-slate-50 px-4 py-4 text-left ring-1 ring-slate-200 hover:bg-slate-100"
            >
              <span className="text-base font-medium text-slate-800">{item}</span>
              <span className="text-slate-400">Abrir</span>
            </button>
          ))}
        </div>
      </div>
    </>
  )
}
