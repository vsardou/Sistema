import BarraTopo from '../components/BarraTopo'

export default function TelaDeclaracoes({ onVoltar }) {
  return (
    <>
      <BarraTopo
        titulo="Declaracoes"
        subtitulo="Campos simples para gerar declaracoes de treinamento sem depender de abrir modelo e editar tudo manualmente."
        voltar
        onVoltar={onVoltar}
      />

      <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200 md:p-8">
        <div className="grid gap-4 md:grid-cols-2">
          <input
            className="rounded-2xl border border-slate-200 px-4 py-4 text-lg"
            placeholder="Nome do aluno"
          />
          <input
            className="rounded-2xl border border-slate-200 px-4 py-4 text-lg"
            placeholder="Tipo de declaracao"
          />
          <input
            className="rounded-2xl border border-slate-200 px-4 py-4 text-lg"
            placeholder="Periodo"
          />
          <input
            className="rounded-2xl border border-slate-200 px-4 py-4 text-lg"
            placeholder="Empresa / observacao"
          />
          <textarea
            className="min-h-[140px] rounded-2xl border border-slate-200 px-4 py-4 text-lg md:col-span-2"
            placeholder="Texto complementar ou descricao livre"
          />
        </div>
        <div className="mt-6 flex flex-col gap-3 md:flex-row">
          <button className="rounded-2xl bg-slate-900 px-5 py-4 text-lg font-semibold text-white">
            Gerar declaracao
          </button>
          <button className="rounded-2xl bg-white px-5 py-4 text-lg font-semibold text-slate-700 ring-1 ring-slate-200">
            Abrir modelo
          </button>
        </div>
      </div>
    </>
  )
}
