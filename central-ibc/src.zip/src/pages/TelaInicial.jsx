import BarraTopo from '../components/BarraTopo'
import CardBotao from '../components/CardBotao'
import { documentosRecentes } from '../data/mockData'

export default function TelaInicial({ onAbrir }) {
  const cards = [
    {
      chave: 'email',
      titulo: 'E-mail',
      emoji: '📧',
      descricao: 'Abre o e-mail no navegador sem procurar link ou favorito.',
      acao: 'Abrir e-mail',
    },
    {
      chave: 'modelos',
      titulo: 'Imprimir Modelos',
      emoji: '🖨️',
      descricao: 'Rascunhos, procedimentos, instrucoes tecnicas e mascara master.',
      acao: 'Ver modelos',
    },
    {
      chave: 'programacao',
      titulo: 'Programacao de Treinamento',
      emoji: '📅',
      descricao: 'Criar, editar e localizar programacoes de forma simples.',
      acao: 'Abrir programacao',
    },
    {
      chave: 'declaracoes',
      titulo: 'Declaracoes',
      emoji: '📄',
      descricao: 'Gerar declaracao de treinamento a partir de campos claros.',
      acao: 'Nova declaracao',
    },
    {
      chave: 'prestacao',
      titulo: 'Prestacao de Contas',
      emoji: '💰',
      descricao: 'Preencher dados do aluno e gerar o Word no modelo pronto.',
      acao: 'Nova prestacao',
    },
    {
      chave: 'buscar',
      titulo: 'Buscar Documento',
      emoji: '🔎',
      descricao: 'Pesquisar por aluno, mes, tipo de documento ou palavra-chave.',
      acao: 'Buscar agora',
    },
  ]

  return (
    <>
      <BarraTopo
        titulo="Painel principal"
        subtitulo="Um ponto unico para abrir e-mail, emitir documentos, localizar arquivos e organizar a rotina do treinamento sem depender de navegar por muitas pastas."
      />

      <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
        {cards.map((card) => (
          <CardBotao
            key={card.chave}
            emoji={card.emoji}
            titulo={card.titulo}
            descricao={card.descricao}
            acao={card.acao}
            onClick={() => onAbrir(card.chave)}
          />
        ))}
      </div>

      <div className="mt-8 grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
        <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200 md:p-8">
          <div className="mb-6 flex items-center justify-between">
            <div>
              <p className="text-sm font-medium uppercase tracking-[0.2em] text-slate-500">
                Fluxo guiado
              </p>
              <h3 className="mt-2 text-2xl font-bold text-slate-900 md:text-3xl">
                Prestacao de contas
              </h3>
            </div>
            <div className="rounded-2xl bg-rose-50 px-4 py-2 text-sm font-semibold text-rose-700">
              Primeiro MVP
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="rounded-2xl bg-slate-50 p-4 ring-1 ring-slate-200">
              <span className="mb-2 block text-sm font-semibold text-slate-600">
                Nome do aluno
              </span>
              <div className="rounded-xl bg-white px-4 py-3 text-slate-400 ring-1 ring-slate-200">
                Ex.: Pablo
              </div>
            </div>
            <div className="rounded-2xl bg-slate-50 p-4 ring-1 ring-slate-200">
              <span className="mb-2 block text-sm font-semibold text-slate-600">Periodo</span>
              <div className="rounded-xl bg-white px-4 py-3 text-slate-400 ring-1 ring-slate-200">
                13/04/2026 a 18/04/2026
              </div>
            </div>
            <div className="rounded-2xl bg-slate-50 p-4 ring-1 ring-slate-200 md:col-span-2">
              <span className="mb-2 block text-sm font-semibold text-slate-600">
                Descreva do seu jeito
              </span>
              <div className="rounded-xl bg-white px-4 py-4 text-slate-400 ring-1 ring-slate-200">
                Treinou de 13 a 18/04, com hospedagem na semana toda. Treinou tambem 25 e
                26/04.
              </div>
            </div>
          </div>

          <div className="mt-6 flex flex-col gap-3 md:flex-row">
            <button className="rounded-2xl bg-slate-900 px-5 py-4 text-lg font-semibold text-white">
              Interpretar com IA
            </button>
            <button className="rounded-2xl bg-white px-5 py-4 text-lg font-semibold text-slate-700 ring-1 ring-slate-200">
              Gerar Word
            </button>
            <button className="rounded-2xl bg-white px-5 py-4 text-lg font-semibold text-slate-700 ring-1 ring-slate-200">
              Abrir modelo
            </button>
          </div>
        </div>

        <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200 md:p-8">
          <p className="text-sm font-medium uppercase tracking-[0.2em] text-slate-500">
            Uso recente
          </p>
          <h3 className="mt-2 text-2xl font-bold text-slate-900 md:text-3xl">
            Documentos recentes
          </h3>
          <div className="mt-6 space-y-3">
            {documentosRecentes.map((item) => (
              <button
                key={item.nome}
                className="flex w-full items-center justify-between rounded-2xl bg-slate-50 px-4 py-4 text-left ring-1 ring-slate-200 transition hover:bg-slate-100"
              >
                <div>
                  <div className="text-base font-medium text-slate-800">{item.nome}</div>
                  <div className="mt-1 text-sm text-slate-500">{item.categoria}</div>
                </div>
                <span className="text-slate-400">→</span>
              </button>
            ))}
          </div>

          <div className="mt-6 rounded-2xl bg-amber-50 p-4 ring-1 ring-amber-200">
            <p className="text-sm font-semibold text-amber-800">Regra de ouro</p>
            <p className="mt-2 text-sm leading-relaxed text-amber-900">
              Seu pai nao escolhe pasta. O sistema abre o modelo certo, gera o
              documento e salva automaticamente no lugar definido.
            </p>
          </div>
        </div>
      </div>
    </>
  )
}
