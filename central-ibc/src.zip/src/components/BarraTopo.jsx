export default function BarraTopo({ titulo, subtitulo, voltar, onVoltar }) {
  return (
    <div className="mb-8 rounded-3xl border border-slate-300 bg-white p-6 shadow-sm md:p-8">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <p className="mb-2 text-sm font-semibold uppercase tracking-[0.2em] text-[#C40010]">
            Central IBC
          </p>
          <h1 className="text-3xl font-bold text-slate-900 md:text-5xl">{titulo}</h1>
          <p className="mt-3 max-w-3xl text-base text-slate-700 md:text-lg">{subtitulo}</p>
        </div>
        {voltar ? (
          <button
            onClick={onVoltar}
            className="rounded-2xl bg-[#C40010] px-5 py-4 text-lg font-semibold text-white transition hover:bg-[#A3000D]"
          >
            Voltar ao painel
          </button>
        ) : (
          <div className="md:w-[360px]">
            <div className="mb-3 overflow-hidden rounded-3xl border border-slate-300 bg-white p-3 shadow-sm">
              <img
                src="/logo-com-fundo.png"
                alt="IBC Qualidade"
                className="h-28 w-full rounded-[20px] object-contain"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <button className="rounded-2xl bg-[#C40010] px-4 py-4 text-base font-semibold text-white shadow-sm transition hover:bg-[#A3000D]">
                Abrir pasta principal
              </button>
              <button className="rounded-2xl bg-white px-4 py-4 text-base font-semibold text-slate-700 shadow-sm ring-1 ring-slate-300 transition hover:bg-slate-50">
                Arquivos recentes
              </button>
              <button className="col-span-2 rounded-2xl bg-white px-4 py-4 text-base font-semibold text-slate-700 shadow-sm ring-1 ring-slate-300 transition hover:bg-slate-50">
                Buscar por nome, mes ou documento
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
