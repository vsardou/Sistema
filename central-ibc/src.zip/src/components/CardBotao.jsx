export default function CardBotao({ emoji, titulo, descricao, acao, onClick }) {
  return (
    <button
      onClick={onClick}
      className="rounded-3xl bg-white p-6 text-left shadow-sm ring-1 ring-slate-200 transition hover:-translate-y-0.5 hover:shadow-md"
    >
      <div className="mb-5 flex items-center gap-4">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-slate-100 text-3xl">
          {emoji}
        </div>
        <div>
          <h2 className="text-2xl font-bold text-slate-900">{titulo}</h2>
        </div>
      </div>
      <p className="min-h-[72px] text-base leading-relaxed text-slate-700">{descricao}</p>
      <div className="mt-6 rounded-2xl bg-slate-900 px-5 py-4 text-center text-lg font-semibold text-white">
        {acao}
      </div>
    </button>
  )
}
