import { useState } from 'react'
import TelaBusca from './pages/TelaBusca'
import TelaDeclaracoes from './pages/TelaDeclaracoes'
import TelaInicial from './pages/TelaInicial'
import TelaModelos from './pages/TelaModelos'
import TelaPrestacao from './pages/TelaPrestacao'
import TelaProgramacao from './pages/TelaProgramacao'

export default function App() {
  const [tela, setTela] = useState('inicio')

  return (
    <div className="min-h-screen bg-slate-100 p-6 md:p-10">
      <div className="mx-auto max-w-7xl">
        {tela === 'inicio' && <TelaInicial onAbrir={setTela} />}
        {tela === 'modelos' && <TelaModelos onVoltar={() => setTela('inicio')} />}
        {tela === 'programacao' && <TelaProgramacao onVoltar={() => setTela('inicio')} />}
        {tela === 'prestacao' && <TelaPrestacao onVoltar={() => setTela('inicio')} />}
        {tela === 'declaracoes' && <TelaDeclaracoes onVoltar={() => setTela('inicio')} />}
        {tela === 'buscar' && <TelaBusca onVoltar={() => setTela('inicio')} />}
        {tela === 'email' && (
          <TelaBusca
            onVoltar={() => setTela('inicio')}
            titulo="E-mail"
            subtitulo="Atalho temporario para a primeira versao, reaproveitando a navegacao existente."
          />
        )}
      </div>
    </div>
  )
}
